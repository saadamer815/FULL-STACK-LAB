let count = 0;

const countDisplay = document.getElementById("count");


function updateCount() {
    countDisplay.textContent = count;
}


document.getElementById("plusBtn").addEventListener("click", function () {

    count++;

    updateCount();
});

document.getElementById("minusBtn").addEventListener("click", function () {

    if (count > 0) {
        count--;
    }

    updateCount();
});
document.getElementById("resetBtn").addEventListener("click", function () {

    count = 0;

    updateCount();
});
document.getElementById("themeBtn").addEventListener("click", function () {

    document.body.classList.toggle("dark");

    if (document.body.classList.contains("dark")) {
        this.textContent = "Light Mode";
    }
    else {
        this.textContent = "Dark Mode";
    }
});