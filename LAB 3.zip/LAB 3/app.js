const button = document.getElementById("calculateBtn");

button.addEventListener("click", function () {

    let name = document.getElementById("studentName").value;
    let marks = Number(document.getElementById("marks").value);

    let result = document.getElementById("result");

    if (name == "") {
        result.innerHTML = "Please enter student name.";
        result.style.color = "red";
        return;
    }

    if (document.getElementById("marks").value == "" || marks < 0 || marks > 100) {
        result.innerHTML = "Please enter marks between 0 and 100.";
        result.style.color = "red";
        return;
    }

    let grade;

    if (marks >= 85) {
        grade = "A";
    }
    else if (marks >= 70) {
        grade = "B";
    }
    else if (marks >= 50) {
        grade = "C";
    }
    else {
        grade = "F";
    }

    result.innerHTML = `${name} scored ${marks} marks - Grade ${grade}`;

    if (grade == "F") {
        result.style.color = "red";
    }
    else {
        result.style.color = "green";
    }

});