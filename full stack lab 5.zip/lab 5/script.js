
const form = document.getElementById("registrationForm");

const fullName = document.getElementById("fullName");
const email = document.getElementById("email");
const program = document.getElementById("program");
const semester = document.getElementById("semester");

const studentList = document.getElementById("studentList");

const previewName = document.getElementById("previewName");
const previewEmail = document.getElementById("previewEmail");
const previewProgram = document.getElementById("previewProgram");
const previewSemester = document.getElementById("previewSemester");

const previewCard = document.getElementById("previewCard");
const darkModeBtn = document.getElementById("darkModeBtn");

const nameInput = document.querySelector("#fullName");


fullName.addEventListener("input", function () {
    previewName.textContent = fullName.value || "Your Name";
});

email.addEventListener("input", function () {
    previewEmail.textContent = email.value || "your@email.com";
});

program.addEventListener("input", function () {
    previewProgram.textContent = program.value || "Your Program";
});

semester.addEventListener("input", function () {
    previewSemester.textContent = semester.value || "-";
});

form.addEventListener("submit", function (event) {

    event.preventDefault();

    document.getElementById("nameError").textContent = "";
    document.getElementById("emailError").textContent = "";
    document.getElementById("programError").textContent = "";
    document.getElementById("semesterError").textContent = "";

    let isValid = true;

    if (fullName.value.trim() === "") {
        document.getElementById("nameError").textContent =
            "Full Name is required.";
        isValid = false;
    }

    if (email.value.trim() === "") {
        document.getElementById("emailError").textContent =
            "Email is required.";
        isValid = false;
    } else if (!email.value.includes("@")) {
        document.getElementById("emailError").textContent =
            "Please enter a valid email.";
        isValid = false;
    }

    if (program.value === "") {
        document.getElementById("programError").textContent =
            "Please select a program.";
        isValid = false;
    }

    if (
        semester.value === "" ||
        semester.value < 1 ||
        semester.value > 8
    ) {
        document.getElementById("semesterError").textContent =
            "Semester must be between 1 and 8.";
        isValid = false;
    }
    if (isValid) {

        const listItem = document.createElement("li");

        listItem.textContent =
            fullName.value +
            " | " +
            email.value +
            " | " +
            program.value +
            " | Semester " +
            semester.value;
        studentList.append(listItem);


        form.reset();

        previewName.textContent = "Your Name";
        previewEmail.textContent = "your@email.com";
        previewProgram.textContent = "Your Program";
        previewSemester.textContent = "-";
    }
});

darkModeBtn.addEventListener("click", function () {
    previewCard.classList.toggle("dark");
});
