function generateFizzBuzz() {

    const limit = Number(document.getElementById("limit").value);
    const result = document.getElementById("result");

    result.innerHTML = "";

    if (limit < 1 || isNaN(limit)) {
        result.textContent = "Please enter a valid number.";
        return;
    }

    for (let i = 1; i <= limit; i++) {

        const listItem = document.createElement("li");

        if (i % 3 === 0 && i % 5 === 0) {
            listItem.textContent = "FizzBuzz";
        }
        else if (i % 3 === 0) {
            listItem.textContent = "Fizz";
        }
        else if (i % 5 === 0) {
            listItem.textContent = "Buzz";
        }
        else {
            listItem.textContent = i;
        }

        result.appendChild(listItem);
    }
}

document.getElementById("generateBtn")
    .addEventListener("click", generateFizzBuzz);